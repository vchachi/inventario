<!-- Text Field -->
<div class="form-group col-sm-12 col-lg-12">
    {!! Form::label('text', 'Texto:') !!}
    {!! Form::textarea('text', null, ['class' => 'form-control']) !!}
</div>